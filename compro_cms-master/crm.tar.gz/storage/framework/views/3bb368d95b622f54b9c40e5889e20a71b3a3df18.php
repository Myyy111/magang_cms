
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>

<!-- Start Content-->
<div class="container-fluid">
    
    <!-- start page title -->
    <!-- Include page breadcrumb -->
    <?php echo $__env->make('admin.inc.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end page title --> 


    <div class="row">
        <div class="col-12">
            <a href="<?php echo e(route($route.'.index')); ?>" class="btn btn-info"><?php echo e(__('dashboard.refresh')); ?></a>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="header-title"><?php echo e($title); ?> <?php echo e(__('dashboard.setup')); ?></h4>
                </div>
                <div class="card-body">

                  <!-- Form Start -->
                  <form class="needs-validation" novalidate action="<?php echo e(route($route.'.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input name="id" type="hidden" value="<?php echo e((isset($row->id))?$row->id:-1); ?>">

                    <div class="row">

                      <div class="col-md-12 col-lg-12">
                          <div class="mb-3">
                              <div class="custom-control custom-radio">
                                  <input type="radio" id="whatsapp" name="status" class="custom-control-input" value="1" <?php if( $row->status == 1 ): ?> checked <?php endif; ?>>
                                  <label class="custom-control-label" for="whatsapp"><?php echo e(__('WhatsApp')); ?></label>
                              </div>
                              <div class="custom-control custom-radio">
                                  <input type="radio" id="messenger" name="status" class="custom-control-input" value="0" <?php if( $row->status == 0 ): ?> checked <?php endif; ?>>
                                  <label class="custom-control-label" for="messenger"><?php echo e(__('Messenger')); ?></label>
                              </div>
                          </div>
                      </div>

                      <div class="col-md-6">
                        <h4><?php echo e(__('dashboard.whatsapp_live_chat')); ?></h4>
                        <hr/>
                        <div class="form-group">
                          <label for="whatsapp_no"><?php echo e(__('dashboard.whatsapp')); ?> <span>(<?php echo e(__('dashboard.inc_country_code')); ?>)</span></label>
                          <input type="text" class="form-control" name="whatsapp_no" id="whatsapp_no" value="<?php echo e(isset($row->whatsapp_no)?$row->whatsapp_no:''); ?>">

                          <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.whatsapp')); ?>

                          </div>
                        </div>

                        <div class="form-group">
                          <label for="whatsapp_title"><?php echo e(__('dashboard.whatsapp_header_title')); ?></label>
                          <input type="text" class="form-control" name="whatsapp_title" id="whatsapp_title" value="<?php echo e(isset($row->whatsapp_title)?$row->whatsapp_title:''); ?>">

                          <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.whatsapp_header_title')); ?>

                          </div>
                        </div>

                        <div class="form-group">
                          <label for="whatsapp_greeting"><?php echo e(__('dashboard.whatsapp_greeting_message')); ?></label>
                          <input type="text" class="form-control" name="whatsapp_greeting" id="whatsapp_greeting" value="<?php echo e(isset($row->whatsapp_greeting)?$row->whatsapp_greeting:''); ?>">

                          <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.whatsapp_greeting_message')); ?>

                          </div>
                        </div>
                      </div>


                      <div class="col-md-6">
                        <h4><?php echo e(__('dashboard.messenger_live_chat')); ?></h4>
                        <hr/>
                        <div class="form-group">
                          <label for="facebook_id"><?php echo e(__('dashboard.facebook_page_id')); ?></label>
                          <input type="text" class="form-control" name="facebook_id" id="facebook_id" value="<?php echo e(isset($row->facebook_id)?$row->facebook_id:''); ?>">

                          <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.facebook_page_id')); ?>

                          </div>
                        </div>

                        <div class="form-group">
                          <label for="facebook_greeting_in"><?php echo e(__('dashboard.facebook_login_greeting')); ?></label>
                          <input type="text" class="form-control" name="facebook_greeting_in" id="facebook_greeting_in" value="<?php echo e(isset($row->facebook_greeting_in)?$row->facebook_greeting_in:''); ?>">

                          <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.facebook_login_greeting')); ?>

                          </div>
                        </div>

                        <div class="form-group">
                          <label for="facebook_greeting_out"><?php echo e(__('dashboard.facebook_logout_greeting')); ?></label>
                          <input type="text" class="form-control" name="facebook_greeting_out" id="facebook_greeting_out" value="<?php echo e(isset($row->facebook_greeting_out)?$row->facebook_greeting_out:''); ?>">

                          <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.facebook_logout_greeting')); ?>

                          </div>
                        </div>
                      </div>

                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><?php echo e(__('dashboard.update')); ?></button>
                    </div>

                  </form>
                  <!-- Form End -->

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->

    
</div> <!-- container -->
<!-- End Content-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/subangkit/Projects/CMSSystem/Compro/MultipurposeBusiness/resources/views/admin/livechat/index.blade.php ENDPATH**/ ?>