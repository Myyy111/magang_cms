
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>

<!-- Start Content-->
<div class="container-fluid">
    
    <!-- start page title -->
    <!-- Include page breadcrumb -->
    <?php echo $__env->make('admin.inc.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end page title --> 


    <div class="row">
        <div class="col-12">
            <a href="<?php echo e(route($route.'.index')); ?>" class="btn btn-info"><?php echo e(__('dashboard.back')); ?></a>
        </div>
    </div>

    <form class="needs-validation" novalidate action="<?php echo e(route($route.'.store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-12 col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="header-title"><?php echo e(__('dashboard.add')); ?> <?php echo e($title); ?></h4>
                </div>
                <div class="card-body">

                    <!-- Form Start -->
                    <div class="form-group">
                        <label for="subject"><?php echo e(__('dashboard.subject')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="subject" id="subject" value="<?php echo e($template_send->title); ?>" required>

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.subject')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="name"><?php echo e(__('dashboard.name')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="name" id="name" value="<?php echo e(old('name')); ?>" required>

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.name')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email"><?php echo e(__('dashboard.email')); ?> <span>*</span></label>
                        <input type="email" class="form-control" name="email" id="email" value="<?php echo e(old('email')); ?>" required>

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.email')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="company"><?php echo e(__('dashboard.company')); ?></label>
                        <input type="text" class="form-control" name="company" id="company" value="<?php echo e(old('company')); ?>">

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.company')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="address"><?php echo e(__('dashboard.address')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="address" id="address" value="<?php echo e(old('address')); ?>" required>

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.address')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="city"><?php echo e(__('dashboard.city')); ?></label>
                        <input type="text" class="form-control" name="city" id="city" value="<?php echo e(old('city')); ?>">

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.city')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="service"><?php echo e(__('dashboard.services')); ?></label>
                        <select class="select2 form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="<?php echo e(__('dashboard.select')); ?>" name="services[]" id="service">
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($service->id); ?>" <?php if(old('service') == $service->id): ?> selected <?php endif; ?>><?php echo e($service->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.services')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="message"><?php echo e(__('dashboard.message')); ?> <span>*</span></label>
                        <textarea class="form-control summernote" name="message" id="message" rows="8" required><?php echo e($template_send->description); ?></textarea>

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.message')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="reference"><?php echo e(__('dashboard.reference')); ?></label>
                        <input type="text" class="form-control" name="reference" id="reference" value="<?php echo e(old('reference')); ?>">

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.reference')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="attach"><?php echo e(__('dashboard.attach')); ?></label>
                        <input type="file" class="form-control" name="attach" id="attach">

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.attach')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div><!-- end col-->
        <div class="col-12 col-lg-4">
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="service_charge"><?php echo e(__('dashboard.service_bill')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="service_charge" id="service_charge" value="<?php echo e(old('service_charge')); ?>" required>

                        <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.service_bill')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="tax"><?php echo e(__('dashboard.tax_charge')); ?></label>
                        <input type="text" class="form-control" name="tax" id="tax" value="<?php echo e(old('tax')); ?>">

                        <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.tax_charge')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="shipping"><?php echo e(__('dashboard.shipping_charge')); ?></label>
                        <input type="text" class="form-control" name="shipping" id="shipping" value="<?php echo e(old('shipping')); ?>">

                        <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.shipping_charge')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="total_amount"><?php echo e(__('dashboard.total_amount')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="total_amount" id="total_amount" value="<?php echo e(old('total_amount')); ?>" required>

                        <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.total_amount')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="invoice_type"><?php echo e(__('dashboard.invoice_type')); ?> <span>*</span></label>
                        <select class="form-control" name="invoice_type" id="invoice_type" required>
                            <option value=""><?php echo e(__('dashboard.select')); ?></option>
                            <option value="0" <?php if(old('invoice_type') == 1): ?> selected <?php endif; ?>><?php echo e(__('dashboard.estimate')); ?></option>
                            <option value="1" <?php if(old('invoice_type') == 1): ?> selected <?php endif; ?>><?php echo e(__('dashboard.advance')); ?></option>
                            <option value="2" <?php if(old('invoice_type') == 2): ?> selected <?php endif; ?>><?php echo e(__('dashboard.interval')); ?></option>
                            <option value="3" <?php if(old('invoice_type') == 3): ?> selected <?php endif; ?>><?php echo e(__('dashboard.milestone')); ?></option>
                            <option value="4" <?php if(old('invoice_type') == 4): ?> selected <?php endif; ?>><?php echo e(__('dashboard.final')); ?></option>
                            <option value="5" <?php if(old('invoice_type') == 5): ?> selected <?php endif; ?>><?php echo e(__('dashboard.full')); ?></option>
                        </select>

                        <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.invoice_type')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="discount_amount"><?php echo e(__('dashboard.discount_amount')); ?></label>
                        <input type="text" class="form-control" name="discount_amount" id="discount_amount" value="<?php echo e(old('discount_amount')); ?>">

                        <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.discount_amount')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="invoice_amount"><?php echo e(__('dashboard.invoice_amount')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="invoice_amount" id="invoice_amount" value="<?php echo e(old('invoice_amount')); ?>" required>

                        <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.invoice_amount')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="due_date"><?php echo e(__('dashboard.due_date')); ?></label>
                        <input type="date" class="form-control" name="due_date" id="due_date" value="<?php echo e(old('due_date')); ?>">

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.due_date')); ?>

                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><?php echo e(__('dashboard.send')); ?></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </form>
    <!-- end row-->

    
</div> <!-- container -->
<!-- End Content-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/subangkit/Projects/Astha/Compro/MultipurposeBusiness/resources/views/admin/invoice/create.blade.php ENDPATH**/ ?>