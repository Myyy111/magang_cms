
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>

<!-- Start Content-->
<div class="container-fluid">
    
    <!-- start page title -->
    <!-- Include page breadcrumb -->
    <?php echo $__env->make('admin.inc.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end page title --> 


    <div class="row">
        <div class="col-12">
            <a href="<?php echo e(route($route.'.index')); ?>" class="btn btn-info"><?php echo e(__('dashboard.back')); ?></a>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="header-title"><?php echo e(__('dashboard.edit')); ?> <?php echo e($title); ?></h4>
                </div>
                <form class="needs-validation" novalidate action="<?php echo e(route($route.'.update', $row->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="card-body">

                    <!-- Form Start -->
                    <div class="form-group">
                        <label for="title"><?php echo e(__('dashboard.name')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="title" id="title" value="<?php echo e($row->title); ?>" required>

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.name')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <label for="designation"><?php echo e(__('dashboard.designation')); ?> <span>*</span></label>
                        <select class="form-control" name="designation" id="designation" required>
                            <option value=""><?php echo e(__('dashboard.select')); ?></option>
                            <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($designation->id); ?>" <?php if( $designation->id == $row->designation_id ): ?> selected <?php endif; ?>><?php echo e($designation->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.designation')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <label for="description"><?php echo e(__('dashboard.description')); ?></label>
                        <textarea class="form-control summernote" name="description" id="description" rows="8"><?php echo e($row->description); ?></textarea>

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.description')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <label for="image"><?php echo e(__('dashboard.photo')); ?> <span><?php echo e(__('dashboard.image_size', ['height' => 500, 'width' => 400])); ?></span></label>
                        <input type="file" class="form-control" name="image" id="image">

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.photo')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <label for="facebook"><?php echo e(__('dashboard.facebook')); ?></label>
                        <input type="url" class="form-control" name="facebook" id="facebook" value="<?php echo e($row->facebook); ?>">

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.facebook')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <label for="twitter"><?php echo e(__('dashboard.twitter')); ?></label>
                        <input type="url" class="form-control" name="twitter" id="twitter" value="<?php echo e($row->twitter); ?>">

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.twitter')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <label for="instagram"><?php echo e(__('dashboard.instagram')); ?></label>
                        <input type="url" class="form-control" name="instagram" id="instagram" value="<?php echo e($row->instagram); ?>">

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.instagram')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <label for="linkedin"><?php echo e(__('dashboard.linkedin')); ?></label>
                        <input type="url" class="form-control" name="linkedin" id="linkedin" value="<?php echo e($row->linkedin); ?>">

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.linkedin')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email"><?php echo e(__('dashboard.email')); ?></label>
                        <input type="email" class="form-control" name="email" id="email" value="<?php echo e($row->email); ?>">

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.email')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <label for="phone"><?php echo e(__('dashboard.phone')); ?></label>
                        <input type="text" class="form-control" name="phone" id="phone" value="<?php echo e($row->phone); ?>">

                        <div class="invalid-feedback">
                          <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.phone')); ?>

                        </div>
                    </div>

                    

                    <div class="form-group">
                        <label for="status"><?php echo e(__('dashboard.select_status')); ?></label>
                        <select class="wide" name="status" id="status" data-plugin="customselect">
                            <option value="1" <?php if( $row->status == 1 ): ?> selected <?php endif; ?>><?php echo e(__('dashboard.active')); ?></option>
                            <option value="0" <?php if( $row->status == 0 ): ?> selected <?php endif; ?>><?php echo e(__('dashboard.inactive')); ?></option>
                        </select>
                    </div>
                    <!-- Form End -->
                    
                </div>
                <div class="card-footer">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><?php echo e(__('dashboard.update')); ?></button>
                    </div>
                </div>
                </form>
            </div>
        </div><!-- end col-->
    </div>
    <!-- end row-->

    
</div> <!-- container -->
<!-- End Content-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/subangkit/Projects/CMSSystem/Compro/MultipurposeBusiness/resources/views/admin/member/edit.blade.php ENDPATH**/ ?>