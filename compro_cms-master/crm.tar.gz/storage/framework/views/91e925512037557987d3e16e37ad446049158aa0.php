    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="#"><?php echo e(__('dashboard.admin')); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                    </ol>
                </div>
                <h4 class="page-title"><?php echo e($title); ?></h4>
            </div>
        </div>
    </div>     
    <!-- end page title --> <?php /**PATH /Users/subangkit/Projects/Astha/Compro/MultipurposeBusiness/resources/views/admin/inc/breadcrumb.blade.php ENDPATH**/ ?>