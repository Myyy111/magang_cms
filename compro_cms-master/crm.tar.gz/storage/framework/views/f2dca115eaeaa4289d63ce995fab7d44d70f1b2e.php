    <!-- Edit modal content -->
    <div id="approveModal-<?php echo e($row->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
              <form class="needs-validation" novalidate action="<?php echo e(route($route.'.action', ['id' => $row->id, 'action' => 'approve'])); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel"><?php echo e($title); ?> #<?php echo e($row->id); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                    <!-- Form Start -->
                    <div class="form-group">
                        <label for="subject"><?php echo e(__('dashboard.subject')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="subject" id="subject" value="<?php echo e($template_approved->title); ?>" required>

                        <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.subject')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="message"><?php echo e(__('dashboard.message')); ?> <span>*</span></label>
                        <textarea class="form-control summernote" name="message" id="message" rows="8" required><?php echo $template_approved->description; ?></textarea>

                        <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.message')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="amount"><?php echo e(__('dashboard.total_amount')); ?> <span>*</span></label>
                        <input type="text" class="form-control" name="amount" id="amount" value="<?php echo e($row->amount); ?>" required>

                        <div class="invalid-feedback">
                            <?php echo e(__('dashboard.please_provide')); ?> <?php echo e(__('dashboard.total_amount')); ?>

                        </div>
                    </div>
                    <!-- Form End -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-dismiss="modal"><?php echo e(__('dashboard.close')); ?></button>
                    <button type="submit" class="btn btn-success"><?php echo e(__('dashboard.approve')); ?></button>
                </div>
              </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal --><?php /**PATH /Users/subangkit/Projects/Astha/Compro/MultipurposeBusiness/resources/views/admin/get-quote/approve.blade.php ENDPATH**/ ?>