<?php

return array (
    'previous' => '&laquo; Sebelumnya',
    'next' => 'Berikutnya &raquo;',
);
