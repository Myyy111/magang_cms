<?php

return array (
    'password' => 'Kata sandi harus terdiri dari minimal delapan karakter dan cocok dengan konfirmasi.',
    'reset' => 'Kata sandi Anda telah direset!',
    'sent' => 'Kami telah mengirimkan tautan reset kata sandi ke email Anda!',
    'token' => 'Token reset kata sandi ini tidak valid.',
    'user' => 'Kami tidak dapat menemukan pengguna dengan alamat email tersebut.',
);
