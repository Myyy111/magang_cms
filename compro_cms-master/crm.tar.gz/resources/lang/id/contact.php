<?php

return array (
    'email' => 'Email',
    'phone' => 'Hubungi Kami',
    'office_time' => 'Jam Kerja',
    'address' => 'Alamat',
    'your_name' => 'Nama Anda *',
    'phone_no' => 'No. Telepon',
    'email_address' => 'Alamat Email *',
    'subject' => 'Subjek *',
    'your_massage' => 'Pesan Anda *',
    'send' => 'Kirim',
);
