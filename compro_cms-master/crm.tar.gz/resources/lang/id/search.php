<?php

return array (
    'search_field' => 'Cari.....',
    'no_result' => 'Tidak Ditemukan Hasil!',
);
