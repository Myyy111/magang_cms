<?php

return array (
    'your_name' => 'Nama Anda *',
    'phone_no' => 'No. Telepon *',
    'email_address' => 'Alamat Email *',
    'address' => 'Alamat *',
    'city' => 'Kota *',
    'company' => 'Perusahaan (Opsional)',
    'prefer_contact' => 'Kontak yang Anda pilih? *',
    'phone' => 'Telepon',
    'email' => 'Email',
    'services' => 'Layanan (Anda dapat memilih lebih dari satu)',
    'your_massage' => 'Tulis Detail Permintaan Penawaran Anda di Sini... *',
    'upload_file' => 'Unggah File (Opsional)',
    'submit' => 'Kirim Sekarang',
);
