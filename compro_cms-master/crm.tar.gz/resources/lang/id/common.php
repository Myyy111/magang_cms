<?php

return array (
    'read_more' => 'Baca Selengkapnya',
    'view_more' => 'Lihat Selengkapnya',
    'get_start' => 'Mulai Sekarang',
    'contact_us' => 'Hubungi Kami',
    'go_home' => 'Kembali ke Beranda',
    'category' => 'Kategori',
    'categories' => 'Kategori',
    'all' => 'Semua',
    'currency' => 'Rp',
    'footer_links' => 'Tautan Berguna',
    'recent_posts' => 'Postingan Terbaru',
);
