<?php

return array (
    'home' => 'Beranda',
    'about' => 'Tentang Kami',
    'services' => 'Layanan',
    'service-detail' => 'Detail Layanan',
    'portfolios' => 'Portofolio',
    'portfolio-detail' => 'Detail Portofolio',
    'pricing' => 'Harga',
    'blog' => 'Blog',
    'blog-detail' => 'Detail Blog',
    'faqs' => 'FAQ',
    'contact' => 'Hubungi Kami',
    'get_quote' => 'Minta Penawaran',
    'error' => 'Kesalahan 404',
    'payment_feedback' => 'Umpan Balik Pembayaran',
);
