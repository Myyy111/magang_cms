<?php

return array (
  'your_name' => 'Your Name *',
  'phone_no' => 'Phone No *',
  'email_address' => 'Email Address *',
  'address' => 'Address *',
  'city' => 'City *',
  'company' => 'Company (Optional)',
  'prefer_contact' => 'What do you prefer for contact? *',
  'phone' => 'Phone',
  'email' => 'Email',
  'services' => 'Services (You can choose multiple)',
  'your_massage' => 'Write Your Quotation Detail Here... *',
  'upload_file' => 'Upload File (Optional)',
  'submit' => 'Submit Now',
);
