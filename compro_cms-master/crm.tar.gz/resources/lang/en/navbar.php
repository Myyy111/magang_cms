<?php

return array (
  'home' => 'Home',
  'about' => 'About Us',
  'services' => 'Services',
  'service-detail' => 'Service Detail',
  'portfolios' => 'Portfolios',
  'portfolio-detail' => 'Portfolio Detail',
  'pricing' => 'Pricing',
  'blog' => 'Blog',
  'blog-detail' => 'Blog Detail',
  'faqs' => 'FAQs',
  'contact' => 'Contact Us',
  'get_quote' => 'Get A Quote',
  'error' => 'Error 404',
  'payment_feedback' => 'Payment Feedback',
);
