<?php

return array (
  'email' => 'Email',
  'phone' => 'Call Us',
  'office_time' => 'Office Time',
  'address' => 'Address',
  'your_name' => 'Your Name *',
  'phone_no' => 'Phone No',
  'email_address' => 'Email Address *',
  'subject' => 'Subject *',
  'your_massage' => 'Your Massage *',
  'send' => 'Send',
);
