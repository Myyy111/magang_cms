<?php

return array (
  'search_field' => 'Search.....',
  'no_result' => 'No Result Found!',
);
